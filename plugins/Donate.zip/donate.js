var fetch = global.nodemodule["node-fetch"];

var donate_get = function donate_get(type, data) {
	(async function () {
		var returntext = `Link donate : https://vrdonate.vn/1603704658ey83l`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	donate_get: donate_get
}