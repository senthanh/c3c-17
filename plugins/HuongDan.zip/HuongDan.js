﻿var HD_get = function (type, data) {
	var returntext = `Chào mừng bạn đã quay trở lại\nBạn có thể bỏ ra 3s để xem hướng dẫn này\nĐây là một con bot để tương tác với nó bạn hãy dùng dấu lệnh (${global.config.commandPrefix)\nLưu ý : Dấu lệnh này có thể thay đổi tùy vào con bot\nĐể biết toàn bộ lệnh bạn hãy dùng ${global.config.commandPrefix}help ( trang số )\nSau khi ${global.config.commandPrefix}help lần đầu bạn hãy để ý cuối câu chat của bot Trang : số/số\nVD : 1/4 số 1 ở đây ám chỉ đang ở trang 1 còn số 4 tứ là 4 trang vậy bot này có 4 trang lệnh\nSố trang lệnh có thể thay đổi tùy thuộc vào số lượng Plugins cài vào bot\nBạn không hiểu lệnh gì ?\nNah không sao bạn có thể dùng lệnh ${global.config.commandPrefix}help < tên lệnh bạn không hiểu >\nLúc này bot sẽ trả lời bạn lệnh này hoạt động như này nếu bạn không hiểu bạn hãy call cho admin bằng lệnh ${global.config.commandPrefix}calladmin < văn bản > để admin truy cập và giúp đỡ bạn hoặc bạn cũng có thể nhờ bạn bè trợ giúp trong trường hợp bạn bè bạn biết dùng họ có thể hướng dẫn bạn\nNhững trường hợp lệnh đặc biệt\nThường sảy ra khi cá lệnh đó dóng vai trò cực quan trọng trong việc chuyển hóa và sử dụng tài nguyên lệnh trong bot lúc này bạn chỉ còn cách là ${global.config.commandPrefix}help < lệnh đặc biệt > bạn đừng lo lệnh đặc biệt đa phần sẽ hướng dẫn cụ thể hơn cho bạn hiểu ^^\nBot bị lỗi thì sao à\nĐừng lo đây chỉ là lỗi tạm thời sẽ được fix sớm thôi\nNhưng trong trường hợp đang dùng mà bị lỗi bạn hãy lập tức báo cho người có chuyên một hoặc dùng lệnh ${global.config.commandPrefix}calladmin < văn bản > để đc sửa và sử lý kịp thời\nCảm ơn bạn đã đọc hướng dẫn này\nChúc bạn sử dụng vui vẻ <3\nBot by Minh Mẫn\nLiên hệ admin tại : https://www.facebook.com/minhman.Diamond hoặc zalo 0708784378`;
	return {
		handler: "internal",
		data: returntext
	}
} 

module.exports = {
	HD_get: HD_get
}