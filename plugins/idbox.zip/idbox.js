var fetch = global.nodemodule["node-fetch"];

var idbox = function idbox(type, data) {
	(async function () {
		var IDs = [];
		for (var y in data.mentions) {
			IDs.push(y);    
		}
		if(IDs.length != 0){
			var returntext = `ID Box chat là : ${data.msgdata.threadID}\r\nLink Box chat là : https://facebook.com/messages/t/ ${data.msgdata.threadID}`;
		} else {
				var returntext = `ID Box chat là : ${data.msgdata.threadID}\r\nLink Box chat là : https://facebook.com/messages/t/${data.msgdata.threadID}`;
        }
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"idbox\" by Diamond";

data.log(onLoadText);

}
module.exports = {
	idbox: idbox
}