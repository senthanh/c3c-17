var streamBuffers = global.nodemodule["stream-buffers"];
var ps = global.nodemodule["promise-streams"];
var path = global.nodemodule.path;
var exec = global.nodemodule["child_process"].spawn;
var fs = global.nodemodule["fs"];
var ytsr = global.nodemodule.ytsr;
var sf = global.nodemodule["sanitize-filename"];
var fetch = global.nodemodule["node-fetch"];
let concat = global.nodemodule["concat-stream"];

var os = require("os");
var http = require("http");
var https = require("https");
var ftp = global.nodemodule["ftp"];

/**
 * Promisify the readable stream.
 * 
 * @param {stream.Readable} stream 
 */
let concatStream = function concatStream(stream) {
    return new Promise(r => {
        stream.pipe(concat(r), { end: true });
    });
}

function promiseFromChildProcess(child) {
    return new Promise(function (resolve, reject) {
        child.addListener("error", reject);
        child.addListener("exit", resolve);
    });
}

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

ensureExists(path.join(__dirname, "..", "MP4Video"));
var tempDir = path.resolve(__dirname, "..", "MP4Video", "temp");
ensureExists(tempDir);

//ytdl module extracting
/* var AdmZip = global.nodemodule["adm-zip"];
var zip = new AdmZip(global.fileMap["yt2mp3_ytdl_zip"]);

zip.extractAllTo(path.join(__dirname, "..", "MP3Voice"));
var ytdl = require(path.join(__dirname, "..", "MP3Voice", "mp3voice_ytdl")); */

var ytdl = global.nodemodule["ytdl-core"];

var yt2mp3Func = async function (type, data, retry) {
	if (data.args.length > 1) {
		var url = data.args[1];
		if (ytdl.validateURL(url)) {
			try {
				var senderID = "";
				var threadID = "";
				switch (type) {
					case "Facebook":
						senderID = data.msgdata.senderID;
						threadID = data.msgdata.threadID;
						break;
					case "Discord": 
						senderID = data.msgdata.author.id;
						if (data.msgdata.channel.type == "dm") {
							threadID = "DC-" + data.msgdata.channel.id;
						} else {
							threadID = "DC-" + data.msgdata.guild.id;
						}
						break;
				}
				var info = await ytdl.getInfo(url);
				data.log("Lấy dữ liệu video từ youtube (for", senderID + ").");
				var isLive = false;
				var duration = 0;
				if (typeof info.player_response != "object") {
					data.log("Lỗi Lỗi Lỗi Lỗi Lỗi");
					data.log("Information data:", JSON.stringify(info, null, 4));
					data.log("ERROR ERROR ERROR ERROR ERROR");
				}
				if (info.player_response && info.player_response.playabilityStatus.status == "OK") {
					var itaglist = [];
					for (var n in info.player_response.streamingData.formats) {
						if (info.player_response.streamingData.formats[n].live) isLive = true;
						if (info.player_response.streamingData.formats[n].approxDurationMs > duration) 
							duration = info.player_response.streamingData.formats[n].approxDurationMs;
						itaglist.push(info.player_response.streamingData.formats[n].itag);
					}
					data.log("Supported itag:", JSON.stringify(itaglist));
					if (duration > 600000) {
						isLive = true;
					}
					
					if (!isLive) {
						var mp4file = ytdl.downloadFromInfo(info);
						var downloadPercent = 0;
						mp4file.on("progress", function(chunk, downloaded, total) {
							downloadPercent = (downloaded / total * 100);
						});
						var id = senderID;
						var xid = type + "-" + id.toString();
						var logDwl = setInterval(function () {
							data.log("Đang tải video \"" + info.videoDetails.title + "\" for", senderID, "at", threadID + ":", downloadPercent.floor(2).toFixed(2) + "%");
							if (downloadPercent.floor(2) == 100) {
								clearInterval(logDwl);
								data.log("Hoàn thành chu kì tải xuống.");
							}
						}, 3111);
						setTimeout(function () {
							if (downloadPercent < 1) {
								mp4file.destroy();
								clearInterval(logDwl);
								data.log("Timed out while downloading data (for", senderID + ").", "Retrying...");
								data.return(yt2mp3Func(type, data, true));
							}
						}, 20000);
						
						mp4file.on("error", function (err) {
							mp4file.destroy();
							data.return({
								handler: "internal",
								data: "Error while downloading \"" + info.videoDetails.title + "\": " + err
							});
						});
						
						ps.collect(mp4file).then(function (mp3content) {
							var randomID = Math.round(Math.random() * 9999).pad(4);
							var rFN = xid + "-" + randomID;
							fs.writeFileSync(path.join(tempDir, rFN + ".webm"), mp3content);
							
							if (type == "Discord") {
								data.return({
									handler: "internal",
									data: "Converting to MP4..."
								});
							}
							
							var p = exec(global.nodemodule["ffmpeg-static"], ["-i", path.join(tempDir, rFN + ".webm"), path.join(tempDir, rFN + ".mp4")]);
							
							function r(error, stdout, stderr) {
								if (error) {
									return data.return({
										handler: "internal",
										data: "Error while converting: " + error
									});
								}
								switch (type) {
									case "Facebook":
										var stream = fs.createReadStream(path.join(tempDir, rFN + ".mp4"));
										data.return({
											handler: "internal-raw",
											data: {
												attachment: [stream],
												body: "Hoàn thành: " + info.videoDetails.title
											}
										});
										stream.on("close", function () {
											try {
												fs.unlinkSync(path.join(tempDir, rFN + ".mp4"));
											} catch (ex) {}
											try {
												fs.unlinkSync(path.join(tempDir, rFN + ".webm"));
											} catch (ex) {}
										});
										break;
								}
							}
							
							p.on("close", async function (code, signal) {		
								if (code != 0) {
									var stdout = wait.for.stream(p.stdout);
									var stderr = wait.for.stream(p.stderr);
									return r(pstderr, pstdout, pstderr);
								}
								r(null, "", "");
							});
							
							p.on("error", function (err) {
								r(err, "", "");
							});
						}).catch(function (err) {
							data.return({
								handler: "internal",
								data: "Errored while downloading \"" + info.videoDetails.title + "\": " + err
							});
						});
						if (!retry) {
							return {
								handler: "internal",
								data: "Downloading video \"" + info.videoDetails.title + "\"..."
							}
						}
					} else {
						return {
							handler: "internal",
							data: "Cannot process that video (Live Stream or length longer than 10 minutes?)."
						}
					}
				} else {
					return {
						handler: "internal",
						data: "This video does not exist, or not accessible."
					}
				}
			} catch (ex) {
				return {
					handler: "internal",
					data: "Error: " + ex.message
				}
			}
		} else {
			return {
				handler: "internal",
				data: "The link provided is not a valid YouTube links."
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Missing youtube link!"
		}
	}
}

var playMusic = async function playMusic(message, stream, name) {
	var connection = await message.member.voice.channel.join();
	var dispatcher = connection.play(stream);
	dispatcher.on("start", () => message.reply(`Going to play \`${name}\`!`));
	dispatcher.on("error", (err) => message.reply(`Welp I got some bugs. Please report this to https://github.com/c3cbot/c3c-0x/issues. \n\`\`\`\n${err}\n\`\`\``));
}

module.exports = {
	MP4VIDEO: yt2mp3Func
}