var fetch = global.nodemodule["node-fetch"];
function onLoad(data) {

var onLoadText = "\n\n";
onLoadText += "=########################################=\n";
onLoadText += "=            You Are Impostor            =\n";
onLoadText += "=########################################=\n";
onLoadText += "= Đang tải Plugins Yêu Đương code gốc by Kaysil và được sửa lại bởi Hungcho =";

data.log(onLoadText);
data.log(data);

}
var yeuduong = function yeuduong(type, data) {
	(async function () {
		var returntext = `YÊU ĐƯƠNG CON CẶC BỐ MẸ Ở NHÀ CÒNG LƯNG ĐI HỌC =))`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"yeuduong\" by hungcho";

data.log(onLoadText);

}
module.exports = {
	yeuduong: yeuduong
}