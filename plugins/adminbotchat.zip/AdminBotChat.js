var fetch = global.nodemodule["node-fetch"];

var adminbotchat_get = function adminbotchat_get(type, data) {
	(async function () {
		var returntext = `Chủ bot : Minh Mẫn(Bindonal)\nLink Facebook Của Hắn :https://www.facebook.com/minhman.Diamond\nID Facebook :100043813175949\nChú ý và lời nhắc nhở : Mỗi nhóm chỉ được phép add một con bot và lưu ý rằng không được phép kick ra nhét vào tránh bị ban\nCảm ơn vì đã sử dụng sản phẩm ^3^`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	adminbotchat_get: adminbotchat_get
}