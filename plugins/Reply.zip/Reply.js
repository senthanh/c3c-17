var wait = global.nodemodule["wait-for-stuff"];
var alo = function(type, data) {
    return {
		handler: "internal",
		data: "Lô con cặc"
	}
}
var hello = function(type, data) {
    return {
		handler: "internal",
		data: "Lô con cặc"
	}
}
var lenny = function(type, data) {
	return {
		handler: "internal",
		data: "( ͡° ͜ʖ ͡°)"
	}
}
var bruh = function(type, data) {
	return {
		handler: "internal",
		data: "bủh"
	}
}
var donate = function(type, data) {
	return {
		handler: "internal",
		data: "http://bitly.com.vn/S65Wi"
	}
}
var admin = function(type, data) {
	return {
		handler: "internal",
		data: "fb.com/giadeptraikhoaito"
	}
}
var CurseCommand = function(type, data) {
    return {
		handler: "internal",
		data: " t⍑╎ᓭ ╎ᓭ ᔑ ᓵ⚍∷ᓭᒷ. D𝙹リ'ℸ ̣  ℸ ̣ ∷ᔑリᓭꖎᔑℸ ̣ ᒷ ╎ℸ ̣ , 𝙹ℸ ̣ ⍑ᒷ∷∴╎ᓭᒷ ||𝙹⚍ ∴╎ꖎꖎ..."
	}
}
var money = function(type, data){
	//global.plugins.economy.operator.add(global.plugins.economy.getID(data.msgdata, type), 1000000000, "joke: cheat");
}


module.exports = {
	lenny,
	money,
	CurseCommand,
	bruh,
	donate,
	admin,
	alo,
	hello
}