var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var path = global.nodemodule["path"];
//https://graph.facebook.com/100024345931050/picture?height=720&width=720
// name = global.data.cacheName["FB-" + id]
var phcomment = async function(type, data) {
	var text = encodeURIComponent(data.args.slice(1).join(" "));
	var sender = data.msgdata.senderID;
	if(text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "phcmt <text> [pOrNhub Comment]"
		}
	} else {
		try {
			var img = "https://graph.facebook.com/" + sender + "/picture?height=720&width=720"
			var name = encodeURIComponent(global.data.cacheName["FB-" + sender]);
			data.log(name)
			data.log(sender)
			data.log(text)
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=phcomment&image=${img}&text=${text}&username=${name}&raw=1`);
			var buffer = await fetchdata.buffer();
				var phcmt = new streamBuffers.ReadableStreamBuffer({
					frequency: 10,
					chunkSize: 1024
				});
				phcmt.path = 'image.png';
				phcmt.put(buffer);
				phcmt.stop();

				 return {
			 		handler: "internal",
			 		data: {
			 			attachment: ([phcmt])
			 		},
			 		noDelay: true
			 	}
		} catch(ex) {data.log(ex)}
	}
}
var trumptweet = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "trumptweet <text> [Đỗ Nam Trung tweet]"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=trumptweet&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 10,
						chunkSize: 1024
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}
module.exports = {
	phcomment: phcomment,
	trumptweet: trumptweet
}